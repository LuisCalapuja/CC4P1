/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.cc4p1;

/**
 *
 * @author HP
 */
public class Cc4p1 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
